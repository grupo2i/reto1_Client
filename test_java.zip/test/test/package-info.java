/**
  * Package containing the TestFx tests for the windows.
  */
package test;
